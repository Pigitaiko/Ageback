require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.20",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  networks: {
    taikoHoodi: {
      url: "https://rpc.hoodi.taiko.xyz",
      chainId: 167012,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    },
    taikoMainnet: {
      url: "https://rpc.mainnet.taiko.xyz",
      chainId: 167000,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    },
  },
  etherscan: {
    apiKey: {
      taikoHoodi: process.env.BLOCKSCOUT_API_KEY || "abc",
      taikoMainnet: process.env.BLOCKSCOUT_API_KEY || "abc",
    },
    customChains: [
      {
        network: "taikoHoodi",
        chainId: 167012,
        urls: {
          apiURL: "https://hoodi.taikoscan.io/api",
          browserURL: "https://hoodi.taikoscan.io",
        },
      },
      {
        network: "taikoMainnet",
        chainId: 167000,
        urls: {
          apiURL: "https://blockscoutapi.mainnet.taiko.xyz/api",
          browserURL: "https://blockscoutapi.mainnet.taiko.xyz",
        },
      },
    ],
  },
};
