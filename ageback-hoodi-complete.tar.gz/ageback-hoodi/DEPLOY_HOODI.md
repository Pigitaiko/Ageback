# 🚀 AGEBACK DEPLOYMENT GUIDE - TAIKO HOODI

## Quick Reference

**Network:** Taiko Hoodi Testnet  
**Chain ID:** 167012  
**RPC URL:** https://rpc.hoodi.taiko.xyz  
**Explorer:** https://hoodi.taikoscan.io  
**Bridge:** https://bridge.taiko.xyz  
**L1 Faucet:** https://hoodi.ethpandaops.io  

**Time to Deploy:** ~15 minutes  
**Cost:** ~0.3 ETH (testnet, free)

---

## Prerequisites (5 minutes)

### 1. Install Node.js 18+

```bash
node --version  # Should show v18+
```

If not installed: https://nodejs.org

### 2. Install MetaMask

- Download: https://metamask.io
- Create a **NEW testnet-only wallet**
- **Save your seed phrase**

### 3. Add Taiko Hoodi to MetaMask

**Automatic (Recommended):**
- Visit: https://chainlist.org/chain/167012
- Click "Add to MetaMask"

**Manual:**
1. MetaMask → Networks → Add Network
2. Enter:
   - **Network Name:** Taiko Hoodi
   - **RPC URL:** https://rpc.hoodi.taiko.xyz
   - **Chain ID:** 167012
   - **Currency Symbol:** ETH
   - **Explorer:** https://hoodi.taikoscan.io
3. Save

---

## Get Testnet ETH (10 minutes)

### Step 1: Get Ethereum Hoodi ETH

1. Visit: https://hoodi.ethpandaops.io
2. Enter your wallet address
3. Request testnet ETH
4. Wait ~1 minute

### Step 2: Bridge to Taiko Hoodi

1. Visit: https://bridge.taiko.xyz
2. Connect MetaMask
3. Select:
   - **From:** Ethereum Hoodi
   - **To:** Taiko Hoodi
   - **Amount:** 0.5 ETH
4. Click "Bridge"
5. Confirm in MetaMask
6. Wait 3-5 minutes

### Step 3: Verify

1. Open MetaMask
2. Switch to "Taiko Hoodi" network
3. Check balance (should show ~0.5 ETH)

---

## Deploy Contracts (5 minutes)

### Step 1: Clone and Install

```bash
# Clone repository
git clone https://github.com/YOUR_USERNAME/ageback-protocol.git
cd ageback-protocol

# Install dependencies
npm install
```

### Step 2: Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Edit .env file
notepad .env  # Windows
nano .env     # Mac/Linux
```

**Add your private key (NO 0x prefix!):**
```
PRIVATE_KEY=your64characterprivatekeyhere
```

**Get private key from MetaMask:**
1. Click ••• next to account → Account Details
2. Show Private Key → Enter password
3. Copy (64 characters, no 0x)
4. Paste into .env

**Save and close**

### Step 3: Compile

```bash
npx hardhat compile
```

**Expected output:**
```
Compiled 5 Solidity files successfully
```

### Step 4: Deploy

```bash
npm run deploy
```

**Expected output:**
```
🚀 Deploying Ageback to Taiko Hoodi Testnet

Deploying with account: 0x...
Account balance: 0.5 ETH

1️⃣  Deploying MockERC8004...
✅ MockERC8004 deployed to: 0xaaaa...
   Explorer: https://hoodi.taikoscan.io/address/0xaaaa...

2️⃣  Deploying RebatePoolManager...
✅ RebatePoolManager deployed to: 0xbbbb...
   Explorer: https://hoodi.taikoscan.io/address/0xbbbb...

[... more contracts ...]

🎉 DEPLOYMENT COMPLETE!

📋 Contract Addresses:
MockERC8004:          0xaaaa...
RebatePoolManager:    0xbbbb...
LoyaltyTierManager:   0xcccc...
ReferralGraph:        0xdddd...
RebateAccumulator:    0xeeee...

💾 Deployment info saved to deployment-info.json
```

**Takes ~2-3 minutes**

### Step 5: Save Addresses

```bash
# View deployment info
cat deployment-info.json  # Mac/Linux
type deployment-info.json  # Windows

# Backup (important!)
cp deployment-info.json deployment-backup.json
```

---

## Verify Contracts (10 minutes)

```bash
# Get your contract addresses from deployment-info.json

# Verify MockERC8004
npx hardhat verify --network taikoHoodi 0xYOUR_ERC8004_ADDRESS

# Verify RebatePoolManager
npx hardhat verify --network taikoHoodi 0xYOUR_POOL_MANAGER_ADDRESS

# Verify LoyaltyTierManager (has constructor arg)
npx hardhat verify --network taikoHoodi 0xYOUR_TIER_MANAGER_ADDRESS 0xYOUR_ERC8004_ADDRESS

# Verify ReferralGraph
npx hardhat verify --network taikoHoodi 0xYOUR_REFERRAL_GRAPH_ADDRESS

# Verify RebateAccumulator (has 2 constructor args)
npx hardhat verify --network taikoHoodi 0xYOUR_ACCUMULATOR_ADDRESS 0xYOUR_POOL_MANAGER_ADDRESS 0xYOUR_WALLET_ADDRESS
```

**Each should show:**
```
Successfully verified contract
https://hoodi.taikoscan.io/address/0x...#code
```

---

## Test Deployment (2 minutes)

```bash
npm run test
```

**Expected output:**
```
🧪 Testing Ageback Protocol on Taiko Hoodi

1️⃣  Minting agent identity...
✅ Agent identity minted

2️⃣  Registering service provider...
✅ Provider registered with 1 ETH deposit, 3% rebate

3️⃣  Checking provider info...
   Deposited: 1.0 ETH
   Rebate %: 3.0 %

[... more tests ...]

✅ ALL TESTS PASSED!
🎉 Ageback is working correctly on Taiko Hoodi!
```

---

## Troubleshooting

### "Insufficient funds"
→ Need more ETH. Get from faucet or bridge more

### "Network error"
→ Check MetaMask is on Taiko Hoodi network

### "Compilation failed"
→ Check Node.js version (need 18+)

### "Verification failed"
→ Wait 30 seconds and try again
→ Check constructor arguments match deployment

### "Transaction failed"
→ Check you have enough ETH for gas
→ Check private key in .env is correct (no 0x!)

---

## Next Steps

1. ✅ Configure demo interface with your contract addresses
2. ✅ Practice demo presentation
3. ✅ Update GitHub repo with deployment info
4. ✅ Share contracts on block explorer

---

## Command Reference

```bash
# Compile contracts
npm run compile

# Deploy to Taiko Hoodi
npm run deploy

# Test deployment
npm run test

# Verify contract
npx hardhat verify --network taikoHoodi <ADDRESS> [CONSTRUCTOR_ARGS]

# View deployment info
cat deployment-info.json
```

---

## Important URLs

- **Faucet:** https://hoodi.ethpandaops.io
- **Bridge:** https://bridge.taiko.xyz
- **Explorer:** https://hoodi.taikoscan.io
- **Chainlist:** https://chainlist.org/chain/167012
- **Taiko Docs:** https://docs.taiko.xyz

---

**You're ready to deploy Ageback on Taiko Hoodi! 🚀**
