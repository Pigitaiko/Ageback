const hre = require("hardhat");

async function main() {
  // Load deployment addresses
  const deployment = require('../deployment-info.json');
  
  console.log("🧪 Testing Ageback Protocol on Taiko Hoodi\n");
  
  const [deployer, provider, agent] = await hre.ethers.getSigners();
  console.log("Deployer:", deployer.address);
  console.log("Provider:", provider.address);
  console.log("Agent:", agent.address, "\n");
  
  // Get contract instances
  const identity = await hre.ethers.getContractAt("MockERC8004", deployment.contracts.MockERC8004);
  const poolManager = await hre.ethers.getContractAt("RebatePoolManager", deployment.contracts.RebatePoolManager);
  const tierManager = await hre.ethers.getContractAt("LoyaltyTierManager", deployment.contracts.LoyaltyTierManager);
  const referralGraph = await hre.ethers.getContractAt("ReferralGraph", deployment.contracts.ReferralGraph);
  const accumulator = await hre.ethers.getContractAt("RebateAccumulator", deployment.contracts.RebateAccumulator);
  
  // Test 1: Mint agent identity
  console.log("1️⃣  Minting agent identity...");
  const tx1 = await identity.mint(agent.address);
  await tx1.wait();
  const agentTokenId = 1; // First minted token
  console.log("✅ Agent identity minted. Token ID:", agentTokenId, "\n");
  
  // Test 2: Register service provider
  console.log("2️⃣  Registering service provider...");
  const tx2 = await poolManager.connect(provider).registerProvider(
    300, // 3% rebate
    "AI Image Generator",
    "DALL-E style image generation API",
    "https://api.example.com",
    "AI Services",
    { value: hre.ethers.parseEther("1") }
  );
  await tx2.wait();
  console.log("✅ Provider registered with 1 ETH deposit, 3% rebate\n");
  
  // Test 3: Check provider info
  console.log("3️⃣  Checking provider info...");
  const providerInfo = await poolManager.providers(provider.address);
  console.log("   Deposited:", hre.ethers.formatEther(providerInfo.depositedAmount), "ETH");
  console.log("   Rebate %:", providerInfo.rebatePercentage / 100, "%");
  console.log("   Active:", providerInfo.isActive, "\n");
  
  // Test 4: Allocate rebate
  console.log("4️⃣  Allocating rebate for agent transaction...");
  const txAmount = hre.ethers.parseEther("0.01"); // $0.01 transaction
  const tx3 = await poolManager.connect(provider).allocateRebate(agent.address, txAmount);
  await tx3.wait();
  const rebateAmount = (txAmount * BigInt(300)) / BigInt(10000); // 3% of transaction
  console.log("✅ Rebate allocated:", hre.ethers.formatEther(rebateAmount), "ETH\n");
  
  // Test 5: Record transaction for tier
  console.log("5️⃣  Recording transaction for loyalty tier...");
  const tx4 = await tierManager.recordTransaction(agentTokenId, txAmount);
  await tx4.wait();
  console.log("✅ Transaction recorded\n");
  
  // Test 6: Check agent stats
  console.log("6️⃣  Checking agent stats...");
  const agentStats = await tierManager.getAgentStats(agentTokenId);
  console.log("   Total Transactions:", agentStats.totalTransactions.toString());
  console.log("   Current Tier:", agentStats.currentTier.toString());
  console.log("   Multiplier:", agentStats.currentMultiplier.toString(), "%\n");
  
  // Test 7: Set referrer
  console.log("7️⃣  Testing referral system...");
  const referrerTokenId = 2;
  const tx5 = await identity.mint(deployer.address);
  await tx5.wait();
  const tx6 = await referralGraph.setReferrer(agentTokenId, referrerTokenId);
  await tx6.wait();
  console.log("✅ Referrer set for agent\n");
  
  // Test 8: Check pool stats
  console.log("8️⃣  Checking pool statistics...");
  const poolStats = await poolManager.providers(provider.address);
  console.log("   Deposited Amount:", hre.ethers.formatEther(poolStats.depositedAmount), "ETH");
  console.log("   Allocated Rewards:", hre.ethers.formatEther(poolStats.allocatedRewards), "ETH");
  console.log("   Available Balance:", hre.ethers.formatEther(poolStats.depositedAmount - poolStats.allocatedRewards), "ETH\n");
  
  console.log("✅ ALL TESTS PASSED!");
  console.log("\n🎉 Ageback is working correctly on Taiko Hoodi!");
  console.log("\n📊 Summary:");
  console.log("  - Agent identity minted");
  console.log("  - Provider registered with rebate pool");
  console.log("  - Rebate allocated successfully");
  console.log("  - Loyalty tier tracking active");
  console.log("  - Referral system functional");
  console.log("\n🔗 View on Explorer:");
  console.log("  ", deployment.explorer);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
