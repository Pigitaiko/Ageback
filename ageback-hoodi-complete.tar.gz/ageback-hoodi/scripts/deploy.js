const hre = require("hardhat");
const fs = require("fs");

async function main() {
  console.log("🚀 Deploying Ageback to Taiko Hoodi Testnet\n");
  
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with account:", deployer.address);
  
  const balance = await hre.ethers.provider.getBalance(deployer.address);
  console.log("Account balance:", hre.ethers.formatEther(balance), "ETH\n");
  
  // 1. Deploy Mock ERC-8004 Identity System
  console.log("1️⃣  Deploying MockERC8004...");
  const ERC8004 = await hre.ethers.getContractFactory("MockERC8004");
  const identity = await ERC8004.deploy();
  await identity.waitForDeployment();
  const identityAddress = await identity.getAddress();
  console.log("✅ MockERC8004 deployed to:", identityAddress);
  console.log("   Explorer:", `https://hoodi.taikoscan.io/address/${identityAddress}\n`);
  
  // 2. Deploy RebatePoolManager
  console.log("2️⃣  Deploying RebatePoolManager...");
  const PoolManager = await hre.ethers.getContractFactory("RebatePoolManager");
  const poolManager = await PoolManager.deploy();
  await poolManager.waitForDeployment();
  const poolManagerAddress = await poolManager.getAddress();
  console.log("✅ RebatePoolManager deployed to:", poolManagerAddress);
  console.log("   Explorer:", `https://hoodi.taikoscan.io/address/${poolManagerAddress}\n`);
  
  // 3. Deploy LoyaltyTierManager
  console.log("3️⃣  Deploying LoyaltyTierManager...");
  const TierManager = await hre.ethers.getContractFactory("LoyaltyTierManager");
  const tierManager = await TierManager.deploy(identityAddress);
  await tierManager.waitForDeployment();
  const tierManagerAddress = await tierManager.getAddress();
  console.log("✅ LoyaltyTierManager deployed to:", tierManagerAddress);
  console.log("   Explorer:", `https://hoodi.taikoscan.io/address/${tierManagerAddress}\n`);
  
  // 4. Deploy ReferralGraph
  console.log("4️⃣  Deploying ReferralGraph...");
  const ReferralGraph = await hre.ethers.getContractFactory("ReferralGraph");
  const referralGraph = await ReferralGraph.deploy();
  await referralGraph.waitForDeployment();
  const referralGraphAddress = await referralGraph.getAddress();
  console.log("✅ ReferralGraph deployed to:", referralGraphAddress);
  console.log("   Explorer:", `https://hoodi.taikoscan.io/address/${referralGraphAddress}\n`);
  
  // 5. Deploy RebateAccumulator
  console.log("5️⃣  Deploying RebateAccumulator...");
  const Accumulator = await hre.ethers.getContractFactory("RebateAccumulator");
  const accumulator = await Accumulator.deploy(poolManagerAddress, deployer.address);
  await accumulator.waitForDeployment();
  const accumulatorAddress = await accumulator.getAddress();
  console.log("✅ RebateAccumulator deployed to:", accumulatorAddress);
  console.log("   Explorer:", `https://hoodi.taikoscan.io/address/${accumulatorAddress}\n`);
  
  // 6. Set up authorizations
  console.log("6️⃣  Setting up authorizations...");
  
  // Allow TierManager to access identity system
  const grantTierTx = await identity.grantRole(
    await identity.MINTER_ROLE(),
    tierManagerAddress
  );
  await grantTierTx.wait();
  
  // Allow Accumulator to access PoolManager
  const grantAccumulatorTx = await poolManager.grantRole(
    await poolManager.ACCUMULATOR_ROLE(),
    accumulatorAddress
  );
  await grantAccumulatorTx.wait();
  
  console.log("✅ Authorizations complete\n");
  
  // Save deployment info
  const deploymentInfo = {
    network: "taikoHoodi",
    chainId: 167012,
    deployer: deployer.address,
    timestamp: new Date().toISOString(),
    contracts: {
      MockERC8004: identityAddress,
      RebatePoolManager: poolManagerAddress,
      LoyaltyTierManager: tierManagerAddress,
      ReferralGraph: referralGraphAddress,
      RebateAccumulator: accumulatorAddress,
    },
    explorer: "https://hoodi.taikoscan.io",
  };
  
  fs.writeFileSync(
    "deployment-info.json",
    JSON.stringify(deploymentInfo, null, 2)
  );
  
  console.log("🎉 DEPLOYMENT COMPLETE!\n");
  console.log("📋 Contract Addresses:");
  console.log("MockERC8004:         ", identityAddress);
  console.log("RebatePoolManager:   ", poolManagerAddress);
  console.log("LoyaltyTierManager:  ", tierManagerAddress);
  console.log("ReferralGraph:       ", referralGraphAddress);
  console.log("RebateAccumulator:   ", accumulatorAddress);
  console.log("\n💾 Deployment info saved to deployment-info.json");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
