# Ageback

> **Cashback for the agentic economy**

The first loyalty protocol built for AI agents on Taiko.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Network: Taiko Hoodi](https://img.shields.io/badge/Network-Taiko%20Hoodi-purple)](https://hoodi.taikoscan.io)

## What is Ageback?

Ageback is a loyalty and rebate protocol designed for AI agent economies. While traditional cashback relies on interchange fees, Ageback creates a new model: service providers fund rebate pools as customer acquisition spend, and agents earn rewards based on verified on-chain usage.

### Key Features

- 🏦 **Provider-funded pools** — Programmatic CAC for the agent economy
- 🎯 **Tiered loyalty** — 1.0×→1.5× multipliers based on usage  
- 🔗 **Composable cascades** — Rebates flow through multi-hop pipelines
- 🌳 **Batch settlement** — Merkle proofs keep claims sub-$0.03
- 🔒 **Security-first** — Locks, limits, circuit breakers, multisig-ready

## Network Information

**Testnet: Taiko Hoodi**
- Chain ID: `167012`
- RPC: `https://rpc.hoodi.taiko.xyz`
- Explorer: `https://hoodi.taikoscan.io`
- Faucet: `https://hoodi.ethpandaops.io`

## Quick Start

### Prerequisites

- Node.js 18+
- MetaMask or compatible wallet
- Testnet ETH on Taiko Hoodi

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/ageback-protocol.git
cd ageback-protocol

# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Add your PRIVATE_KEY to .env (no 0x prefix)
```

### Get Testnet ETH

1. Get Ethereum Hoodi ETH: https://hoodi.ethpandaops.io
2. Bridge to Taiko Hoodi: https://bridge.taiko.xyz
3. Wait ~5 minutes for bridge completion

### Deploy Contracts

```bash
# Compile contracts
npm run compile

# Deploy to Taiko Hoodi
npm run deploy

# Test deployment
npm run test
```

### Verify Contracts

```bash
# After deployment, verify each contract
npx hardhat verify --network taikoHoodi <CONTRACT_ADDRESS>

# With constructor arguments
npx hardhat verify --network taikoHoodi <CONTRACT_ADDRESS> <ARG1> <ARG2>
```

## Contract Architecture

```
┌─────────────────────────────────────────────┐
│           Ageback Protocol                  │
├─────────────────────────────────────────────┤
│                                             │
│  ┌──────────────┐      ┌──────────────┐   │
│  │   Provider   │─────▶│ RebatePool   │   │
│  │  (deposits)  │      │   Manager    │   │
│  └──────────────┘      └──────┬───────┘   │
│                               │            │
│                               ▼            │
│  ┌──────────────┐      ┌──────────────┐   │
│  │    Agent     │◀─────│   Loyalty    │   │
│  │  (ERC-8004)  │      │     Tier     │   │
│  └──────────────┘      └──────────────┘   │
│                                            │
│  ┌──────────────┐      ┌──────────────┐   │
│  │   Referral   │      │   Rebate     │   │
│  │    Graph     │      │ Accumulator  │   │
│  └──────────────┘      └──────────────┘   │
└─────────────────────────────────────────────┘
```

## Smart Contracts

### Core Contracts

- **MockERC8004** — Agent identity system
- **RebatePoolManager** — Provider deposits and allocations
- **LoyaltyTierManager** — Tier tracking with ERC-8004 identities
- **ReferralGraph** — Referral bonuses with anti-Sybil
- **RebateAccumulator** — Weekly Merkle tree batch claims

### Security Features

- 30-day withdrawal lock
- 20% weekly withdrawal limits
- Circuit breakers (pausable)
- Role-based access control
- Reentrancy guards
- Multisig-ready operator

## Usage Example

### For Service Providers

```javascript
// Register as a provider
await poolManager.registerProvider(
  300,                          // 3% rebate
  "AI Image Generator",         // Service name
  "DALL-E style API",          // Description
  "https://api.example.com",   // Endpoint
  "AI Services",               // Category
  { value: ethers.parseEther("10") } // 10 ETH deposit
);

// Allocate rebate after agent transaction
await poolManager.allocateRebate(
  agentAddress,
  ethers.parseEther("0.01")    // Transaction amount
);
```

### For Agents

```javascript
// Mint agent identity
await identity.mint(agentAddress);

// Check loyalty tier
const stats = await tierManager.getAgentStats(tokenId);
console.log("Tier:", stats.currentTier);      // 0-3
console.log("Multiplier:", stats.currentMultiplier); // 100-150
```

## Economics

- **Provider CAC:** ~$0.30 per agent (vs $50-500 for traditional SaaS)
- **Agent Income:** $6-9/month passive for high-volume agents
- **Claim Cost:** ~$0.026 on Taiko (single claim)
- **Max Rebate:** 10% of transaction
- **Top Tier Multiplier:** 1.5× (1000+ transactions)

## Development

```bash
# Run tests
npm test

# Compile contracts
npm run compile

# Deploy to testnet
npm run deploy

# Verify contracts
npm run verify
```

## Project Structure

```
ageback-protocol/
├── contracts/
│   ├── RebatePoolManager.sol
│   ├── LoyaltyTierManager.sol
│   ├── ReferralGraph.sol
│   ├── RebateAccumulator.sol
│   └── MockERC8004.sol
├── scripts/
│   ├── deploy.js
│   └── test-deployed.js
├── hardhat.config.js
├── package.json
└── README.md
```

## Documentation

- [Whitepaper](./docs/whitepaper.md) — Technical deep dive
- [Deployment Guide](./docs/deployment.md) — Step-by-step deployment
- [Demo Guide](./docs/demo.md) — How to demo Ageback

## Roadmap

**Q1 2026**
- ✅ Taiko Hoodi testnet deployment
- ⏳ Security audit (Trail of Bits)
- ⏳ Mainnet deployment

**Q2 2026**
- Mainnet launch on Taiko Alethia
- SDK and API release
- Provider onboarding program

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for details.

## Security

This is a testnet deployment. For security concerns, please contact: security@ageback.io

## License

MIT License - see [LICENSE](./LICENSE) for details.

## Links

- **Website:** https://ageback.io
- **Documentation:** https://docs.ageback.io
- **Twitter:** https://twitter.com/agebackprotocol
- **Discord:** https://discord.gg/ageback

---

**Built with ❤️ for the agentic economy on Taiko**
