// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title MockERC8004
 * @notice Minimal ERC-8004 implementation for testing
 * @dev In production, use a proper identity system
 */
contract MockERC8004 {
    mapping(uint256 => address) private _owners;
    mapping(uint256 => uint256) private _reputation;
    uint256 public nextTokenId = 1;
    
    event Transfer(address indexed from, address indexed to, uint256 indexed tokenId);
    event ReputationUpdated(uint256 indexed tokenId, uint256 newReputation);
    
    /**
     * @notice Mint new identity token
     */
    function mint(address to) external returns (uint256) {
        require(to != address(0), "Invalid address");
        
        uint256 tokenId = nextTokenId++;
        _owners[tokenId] = to;
        _reputation[tokenId] = 100; // Default reputation
        
        emit Transfer(address(0), to, tokenId);
        return tokenId;
    }
    
    /**
     * @notice Get token owner
     */
    function ownerOf(uint256 tokenId) external view returns (address) {
        address owner = _owners[tokenId];
        require(owner != address(0), "Token does not exist");
        return owner;
    }
    
    /**
     * @notice Get reputation score
     */
    function getReputation(uint256 tokenId) external view returns (uint256) {
        require(_owners[tokenId] != address(0), "Token does not exist");
        return _reputation[tokenId];
    }
    
    /**
     * @notice Update reputation (for testing)
     */
    function setReputation(uint256 tokenId, uint256 newReputation) external {
        require(_owners[tokenId] != address(0), "Token does not exist");
        _reputation[tokenId] = newReputation;
        emit ReputationUpdated(tokenId, newReputation);
    }
}
